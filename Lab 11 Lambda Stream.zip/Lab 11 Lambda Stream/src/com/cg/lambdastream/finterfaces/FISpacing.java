package com.cg.lambdastream.finterfaces;
@FunctionalInterface
public interface FISpacing {
	String spacing(String str);
}