package com.cg.thread;

public class ThreadNum extends Thread {
	
			private String str;
	
			public ThreadNum(String s)
			{
				this.str=s;
			}
			
			public String getStr() {
				return str;
			}
			public void setStr(String str) {
				this.str = str;
			}
			
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ThreadNum thr1 = new ThreadNum("Thread1");
		ThreadNum thr2 = new ThreadNum("Thread2");
		
		thr1.start();
		thr2.start();
		
	}
	
	public void run()
	{
		long num = Math.round(Math.random());
		System.out.println("Random Number := "+num);	
		if(this.getStr().equals("Thread2"))
		ThreadNum.factorial(num);
	}
	public static long factorial(long number)
	{
		long i,fact=1;
		for(i=1;i<=number;i++){
		fact=fact*i;
		}
		System.out.println("Factorial is  := "+fact);
		return fact;
	}
}
